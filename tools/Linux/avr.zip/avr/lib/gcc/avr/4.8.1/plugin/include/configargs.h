/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.8.1/configure --enable-fixed-point --enable-languages=c,c++ --prefix=/home/jenkins/jenkins/jobs/toolchain-avr-linux64/workspace/objdir --enable-long-long --disable-nls --disable-checking --disable-libssp --disable-libada --disable-shared --enable-lto --with-avrlibc=yes --with-dwarf2 --disable-doc --target=avr";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
